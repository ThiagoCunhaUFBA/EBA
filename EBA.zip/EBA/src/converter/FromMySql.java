/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package converter;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import model.Commit;
import model.TDataset;
import view.Histogram;

/**
 *
 * @author THIAGO
 */
public class FromMySql {
    static public ArrayList<Commit> CarregarDados (){
        
        ArrayList<Commit> listatemp = new ArrayList<Commit>();
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/baseapp?user=root&password=1234");
            Statement stmt = conn.createStatement();
            String querylocal = "select *, \n" +
            "extract(day from data) as dia, extract(month from data) as mes, \n" +
            "extract(year from data) as ano, extract(hour from hora) as hora, extract(minute from hora) as minuto, "
                    + "extract(second from hora) as segundo from commit";
            ResultSet rs = stmt.executeQuery(querylocal);                       
            while(rs.next()){                    
                    Calendar datatemp = Calendar.getInstance();                    
                    datatemp.set(rs.getInt("ano"), rs.getInt("mes"), rs.getInt("dia"), rs.getInt("hora"), rs.getInt("minuto"), rs.getInt("segundo"));                                                            
                    listatemp.add(new Commit(rs.getString("revisao"), rs.getString("caminho"), rs.getString("operacao"), datatemp, rs.getString("autor")));                    
            }
            
            
       }catch(SQLException ex){                            
                System.out.println("SQLException: " + ex.getMessage());
                System.out.println("SQLState: " + ex.getSQLState());
                System.out.println("VendorError: " + ex.getErrorCode());
       }  catch(Exception e){
        System.out.println("Problemas ao tentar conectar com o banco de dados");	
    }
        
        
 
        return listatemp;
    }
}

