/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package converter;

import java.io.File;
import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.CSVLoader;

/**
 *
 * @author thiago
 */
public class CSVtoARFF {
    public static void main(String filein, String fileout) throws Exception{
        CSVLoader loader = new CSVLoader();
        loader.setSource(new File(filein));
        Instances data = loader.getDataSet();        
        ArffSaver saver = new ArffSaver();
        saver.setInstances(data);
        saver.setFile(new File(fileout));
        saver.writeBatch();
                
    }
    
}
