
package DAO;
import model.Commit;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import util.FabricaConexao;


/**
 *
 * @author thiago
 */
public class CommitDao {
/*
        private final String INSERT = "INSERT INTO commit (revisao, path, operacao, tipo, data, hora, autor) VALUES (?, ?, ?, ?, ?, ?, ?)";
	private final String UPDATE = "UPDATE commit SET revisao = ?, path = ?, operacao = ?, tipo = ?, data = ?, hora = ?, autor  = ? WHERE ID=?";
	private final String DELETE = "DELETE FROM commit WHERE ID =?";
	private final String LIST = "SELECT * FROM commit";
	private final String LISTBYID = "SELECT * FROM commit WHERE ID=?";

	public void inserir(Commit commit) {
		if (commit != null) {
			Connection conn = null;
			try {
				conn = FabricaConexao.getConexao();
				PreparedStatement pstm;
				pstm = conn.prepareStatement(INSERT);

				pstm.setInt(1, commit.getRevisao());
                                pstm.setString(2, commit.getPath());
                                pstm.setString(3, commit.getOperacao());                                
                                pstm.setString(4, commit.getTipo());                                
                                //pstm.setString(5, commit.getData());                                
                                //pstm.setString(6, commit.getHora());                 
                                pstm.setString(7, commit.getAutor());                                	                                
				pstm.execute();
				JOptionPane.showMessageDialog(null, "Commit inserido no Banco de Dados");
				FabricaConexao.fechaConexao(conn, pstm);

			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Erro ao dados no Banco de Dados" + e.getMessage());						
			}
		} else {
			System.out.println("Erro - Vazio");
		}
	}

	public void atualizar(Commit commit) {
		if (commit != null) {
			Connection conn = null;
			try {
				conn = FabricaConexao.getConexao();
				PreparedStatement pstm;
				pstm = conn.prepareStatement(UPDATE);
				pstm.setInt(1, commit.getRevisao());
                                pstm.setString(2, commit.getPath());
                                pstm.setString(3, commit.getOperacao());                                
                                pstm.setString(4, commit.getTipo());                                
                                //pstm.setString(5, commit.getData());                                
                                //pstm.setString(6, commit.getHora());                 
                                pstm.setString(7, commit.getAutor());                                	                                
                                
                                
				

				pstm.execute();
				JOptionPane.showMessageDialog(null, "Commit Atualizado com Sucesso");
				FabricaConexao.fechaConexao(conn);

			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, "Erro ao atualizar commit no banco de"
						+ "dados " + e.getMessage());
			}
		} else {
			JOptionPane.showMessageDialog(null, "O commit enviado por parâmetro está vazio");
		}


	}

	public void remover(int id) {
		Connection conn = null;
		try {
			conn = FabricaConexao.getConexao();
			PreparedStatement pstm;
			pstm = conn.prepareStatement(DELETE);

			pstm.setInt(1, id);

			pstm.execute();
			FabricaConexao.fechaConexao(conn, pstm);

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Erro ao excluir commit do banco de"
					+ "dados " + e.getMessage());
		}
	}

	
        
        
        
        
        public List<Commit> getCommits() {
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		ArrayList<Commit> commits = new ArrayList<Commit>();
		try {
			conn = FabricaConexao.getConexao();
			pstm = conn.prepareStatement(LIST);
			rs = pstm.executeQuery();
			while (rs.next()) {
				Commit commit = new Commit();

				commit.setRevisao(rs.getInt("revisao"));
                                commit.setPath(rs.getString("path"));
                                commit.setOperacao(rs.getString("operacao"));
                                commit.setTipo(rs.getString("tipo"));
                                //commit.setData(rs.getString("data"));
                                //commit.setHora(rs.getString("hora"));
                                commit.setAutor(rs.getString("autor"));
				commits.add(commit);
			}
			FabricaConexao.fechaConexao(conn, pstm, rs);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Erro ao listar commits" + e.getMessage());
		}
		return commits;
	}
        
        
        
        
        
        

	public Commit getCommitById(int id) {
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		Commit commit = new Commit();
		try {
			conn = FabricaConexao.getConexao();
			pstm = conn.prepareStatement(LISTBYID);
			pstm.setInt(1, id);
			rs = pstm.executeQuery();
			while (rs.next()) {
				commit.setRevisao(rs.getInt("revisao"));
                                commit.setPath(rs.getString("path"));
                                commit.setOperacao(rs.getString("operacao"));
                                commit.setTipo(rs.getString("tipo"));
                                //commit.setData(rs.getString("data"));
                                //commit.setHora(rs.getString("hora"));
                                commit.setAutor(rs.getString("autor"));
			}
			FabricaConexao.fechaConexao(conn, pstm, rs);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Erro ao listar commits" + e.getMessage());
		}
		return commit;
	}    */}    

