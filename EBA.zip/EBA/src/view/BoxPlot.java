/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.util.ArrayList;
import javax.swing.JFrame;
import model.TDataset;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;


public class BoxPlot extends JFrame{

/*


    private static final long serialVersionUID = 1L;

    public BoxPlot(String applicationTitle, String TituloGrafico, ArrayList<TDataset> Lista) {   
        super(applicationTitle);
        
        
        DefaultBoxAndWhiskerCategoryDataset ds = new DefaultBoxAndWhiskerCategoryDataset();
        
        ds.add(listMap.get(fields[index]), "Series1", fields[index]); //$NON-NLS-1$ 
        ds.add(Lista.get(0).getAcumulado(),10 ,Lista.get(0).getFrequencia());
        /*
        for (int i = 0; i < Lista.size(); i++ )
        
        {            
                    ds.add(Lista, "termo a ", "termo b");                    
        }
        */
        //DatasetGrafico.addValue(101, "Frequencia", "termo b");
        //DatasetGrafico.addValue(150, "termc1", "termo c2");
        
        /*
        JFreeChart grafico = ChartFactory.createBarChart(TituloGrafico, "Legends", "Number of review", ds);
        
        
        
        this.add(new ChartPanel (grafico));
        this.pack();
 }
    */
}    

