This directory contains common ant build tasks for 
building plugins.

eclipse-formatting.xml is a java formatting file which you can import into
Eclipse to make your Java code confirm to Slava's style.

